package com.metropolitan.pz;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class Izmena extends AppCompatActivity {

    int y, m, d, h, min;
    EditText txtDatumIzmena, txtVremeIzmena;
    DbAdapter dbHandler;
    EditText txtimeIzmena, txtprezimeIzmena, txtUslugaIzmena, txtTelefonIzmena;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.izmena);

        dbHandler = new DbAdapter(this);
        dbHandler.open();

        txtDatumIzmena = findViewById(R.id.txtDatumIzmena);
        txtVremeIzmena = findViewById(R.id.txtVremeIzmena);
        txtimeIzmena = findViewById(R.id.txtimeIzmena);
        txtprezimeIzmena = findViewById(R.id.txtprezimeIzmena);
        txtUslugaIzmena = findViewById(R.id.txtUslugaIzmena);
        txtTelefonIzmena = findViewById(R.id.txtTelefonIzmena);
    }

    public void biranjeDatuma(View view) {

        final Calendar c = Calendar.getInstance();
        y = c.get(Calendar.YEAR);
        m = c.get(Calendar.MONTH);
        d = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view1, year, monthOfYear, dayOfMonth) -> txtDatumIzmena.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year), y, m, d);
        datePickerDialog.show();
    }

    public void biranjeVremena(View view) {

        final Calendar c = Calendar.getInstance();
        h = c.get(Calendar.HOUR_OF_DAY);
        min = c.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                (view1, hourOfDay, minute) -> txtVremeIzmena.setText(hourOfDay + ":" + minute), h, min, false);
        timePickerDialog.show();
    }

    public void onClickIzmena(View view){
        Bundle bundle = getIntent().getExtras();
        int counter = bundle.getInt("counterID");
        String ime = txtimeIzmena.getText().toString();
        String prezime = txtprezimeIzmena.getText().toString();
        String uslug = txtUslugaIzmena.getText().toString();
        String tel = txtTelefonIzmena.getText().toString();
        String datum = txtDatumIzmena.getText().toString();
        String vreme = txtVremeIzmena.getText().toString();
        dbHandler.izmeni(counter, ime, prezime, uslug, tel, datum, vreme);
       // String cc2 = Integer.toString(counter);
        Toast.makeText(getApplicationContext(),
                "Zapis je uspešno izmenjen.", Toast.LENGTH_SHORT).show();


        Intent i = new Intent(this, IzlistajAdaptorActivity.class);
        startActivity(i);

    }
}
