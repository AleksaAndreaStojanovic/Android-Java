package com.metropolitan.pz;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.FilterQueryProvider;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class IzlistajAdaptorActivity extends AppCompatActivity  {

    private ArrayList<Zakazivanje> terminiArrayList;
    private DbAdapter dbHelper;
    private SimpleCursorAdapter dataAdapter;

    ListView listView;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.zakazivanja);

        listView = (ListView) findViewById(R.id.listView1);

        dbHelper = new DbAdapter(this);
        dbHelper.open();
        terminiArrayList = new ArrayList<>();

        listView.setAdapter(dataAdapter);
         registerForContextMenu(listView);

        displayListView();

    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        int position = 0;
        if (item.getItemId() == R.id.obrisiZapis){

            Cursor cursor = (Cursor) listView.getItemAtPosition(position);
           int countryCode = cursor.getInt(cursor.getColumnIndexOrThrow("_id"));
            dbHelper.obrisi(countryCode);
            Toast.makeText(getApplicationContext(),
                    "Zapis je uspešno obrisan.", Toast.LENGTH_SHORT).show();
            displayListView();

            return true;
        }else if (item.getItemId() == R.id.izmeniZapis){
            Cursor cursor = (Cursor) listView.getItemAtPosition(position);
            Integer countryCode = cursor.getInt(cursor.getColumnIndexOrThrow("_id"));

            Intent i = new Intent(this, Izmena.class);
            i.putExtra("counterID", countryCode);
            startActivity(i);
        }
        return false;
    }


    private void displayListView() {


        Cursor cursor = dbHelper.fetchAllCountries();


        String[] columns = new String[] {

                DbAdapter.KEY_IME,
                DbAdapter.KEY_PREZIME,
                DbAdapter.KEY_USLUGA,
                DbAdapter.KEY_TELEFON,
                DbAdapter.KEY_DATUM,
                DbAdapter.KEY_VREME
        };


        int[] to = new int[] {

                R.id.ime,
                R.id.prezime,
                R.id.usluga,
                R.id.telefon,
                R.id.datum,
                R.id.vreme
        };


        dataAdapter = new SimpleCursorAdapter(
                this, R.layout.country_info,
                cursor,
                columns,
                to,
                0);

        ListView listView = (ListView) findViewById(R.id.listView1);

        listView.setAdapter(dataAdapter);


        listView.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> listView, View view,
                                    int position, long id) {

                Cursor cursor = (Cursor) listView.getItemAtPosition(position);


                String countryCode =
                        cursor.getString(cursor.getColumnIndexOrThrow("_id"));
                Toast.makeText(getApplicationContext(),
                        countryCode, Toast.LENGTH_SHORT).show();

            }
        });

        EditText myFilter = (EditText) findViewById(R.id.myFilter);
        myFilter.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                dataAdapter.getFilter().filter(s.toString());
            }
        });

        dataAdapter.setFilterQueryProvider(new FilterQueryProvider() {
            public Cursor runQuery(CharSequence constraint) {
                return dbHelper.fetchCountriesByName(constraint.toString());
            }
        });

    }
}