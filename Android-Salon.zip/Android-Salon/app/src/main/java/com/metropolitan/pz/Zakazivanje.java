package com.metropolitan.pz;

public class Zakazivanje {


    String ime = null;
    String prezime = null;
    String usluga = null;
    String telefon = null;
    String datum = null;
    String vreme = null;



    public String getIme() {
        return ime;
    }

    public void setIme(String imePac) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezimePac) {
        this.prezime = prezime;
    }

    public String getUsluga() {
        return usluga;
    }

    public void setUsluga(String usluga) {
        this.usluga = usluga;
    }

    public String getTelefon() {
        return telefon;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    public String getDatum() {
        return datum;
    }

    public void setDatum(String datum) {
        this.datum = datum;
    }

    public String getVreme() {
        return vreme;
    }

    public void setVreme(String vreme) {
        this.vreme = vreme;
    }
}