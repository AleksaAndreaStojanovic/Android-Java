package com.metropolitan.pz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DbAdapter {

    public static final String KEY_ROWID = "_id";

    public static final String KEY_IME = "ime";
    public static final String KEY_PREZIME = "prezime";
    public static final String KEY_USLUGA = "usluga";
    public static final String KEY_TELEFON = "telefon";
    public static final String KEY_DATUM = "datum";
    public static final String KEY_VREME = "vreme";

    private static final String TAG = "TerminiDbAdapter";
    private DatabaseHelper mDbHelper;
    private SQLiteDatabase mDb;

    private static final String DATABASE_NAME = "salon";
    private static final String SQLITE_TABLE = "zakazivanje";
    private static final int DATABASE_VERSION = 1;

    private final Context mCtx;

    private static final String DATABASE_CREATE =
            "CREATE TABLE if not exists " + SQLITE_TABLE + " (" +
                    KEY_ROWID + " integer PRIMARY KEY autoincrement," +
                    KEY_IME + "," +
                    KEY_PREZIME + "," +
                    KEY_USLUGA + "," +
                    KEY_TELEFON + "," +
                    KEY_DATUM + "," +
                    KEY_VREME +");";

    private static class DatabaseHelper extends SQLiteOpenHelper {

        DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
           SQLiteDatabase mDb = this.getWritableDatabase();
        }


        @Override
        public void onCreate(SQLiteDatabase db) {
            Log.w(TAG, DATABASE_CREATE);
            db.execSQL(DATABASE_CREATE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destroy all old data");
            db.execSQL("DROP TABLE IF EXISTS " + SQLITE_TABLE);
            onCreate(db);
        }
    }

    public DbAdapter(Context ctx) {
        this.mCtx = ctx;
    }

    public DbAdapter open() throws SQLException {
        mDbHelper = new DatabaseHelper(mCtx);
        mDb = mDbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        if (mDbHelper != null) {
            mDbHelper.close();
        }
    }

    public void createCountry(
                              String ime,
                              String prezime, String usluga, String telefon, String datum,
                              String vreme) {

        mDbHelper = new DatabaseHelper(mCtx);
        mDb = mDbHelper.getWritableDatabase();

        ContentValues initialValues = new ContentValues();


        initialValues.put(KEY_IME, ime);
        initialValues.put(KEY_PREZIME, prezime);
        initialValues.put(KEY_USLUGA, usluga);
        initialValues.put(KEY_TELEFON, telefon);
        initialValues.put(KEY_DATUM, datum);
        initialValues.put(KEY_VREME, vreme);

        mDb.insert(SQLITE_TABLE, null, initialValues);
        mDb.close();
    }


    public void obrisi(int id){

        String query = "DELETE FROM " + SQLITE_TABLE + " WHERE _id = " + id +";";
        mDb.execSQL(query);
    }

    public void izmeni(int id,
                       String ime,
                       String prezime, String usluga, String telefon, String datum,
                       String vreme){

        String query = "UPDATE " + SQLITE_TABLE + " SET ime = '" +ime + "', prezime = '" + prezime + "', usluga = '" + usluga + "', telefon = '" + telefon + "', datum = '" + datum + "', vreme = '" + vreme +"' WHERE _id = " + id +";";
        mDb.execSQL(query);
    }

    public Cursor fetchCountriesByName(String inputText) throws SQLException {
        Log.w(TAG, inputText);
        Cursor mCursor = null;
        if (inputText == null  ||  inputText.length () == 0)  {
            mCursor = mDb.query(SQLITE_TABLE, new String[] {KEY_ROWID,
                             KEY_IME, KEY_PREZIME, KEY_USLUGA, KEY_TELEFON, KEY_DATUM, KEY_VREME},
                    null, null, null, null, null);

        }
        else {
            mCursor = mDb.query(true, SQLITE_TABLE, new String[] {KEY_ROWID,
                             KEY_IME, KEY_PREZIME, KEY_USLUGA, KEY_TELEFON, KEY_DATUM, KEY_VREME},
                    KEY_IME  + " like '%" + inputText + "%'", null,
                    null, null, null, null);
        }
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;

    }

    public Cursor fetchAllCountries() {

        Cursor mCursor = mDb.query(SQLITE_TABLE, new String[] {KEY_ROWID,
                        KEY_IME, KEY_PREZIME, KEY_USLUGA, KEY_TELEFON, KEY_DATUM, KEY_VREME},
                null, null, null, null, null);

        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
    }



}