package com.metropolitan.pz;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Lokacija extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lokacija);

        WebView webView = findViewById(R.id.webView);

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webView.loadUrl("https://www.google.com/maps/place/BEAUTY+BOOM/@44.8118628,20.4745813,17z/data=!3m1!4b1!4m5!3m4!1s0x475a7abd4692ca27:0xa458e5baa19f4b19!8m2!3d44.8118628!4d20.47677");
    }
}
