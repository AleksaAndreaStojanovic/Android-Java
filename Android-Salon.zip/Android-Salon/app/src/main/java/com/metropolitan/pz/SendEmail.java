package com.metropolitan.pz;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class SendEmail extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.emails);
    }

    public void onClickEmail(View v) {
        EditText poruka = (EditText)findViewById(R.id.txtPoruka);
        EditText naslov = (EditText)findViewById(R.id.txtNaslov);
        EditText carbonc = (EditText)findViewById(R.id.txtCarbonc);
        String[] to =
                {"maja.starovlas.3983@metropolitan.ac.rs"};

        sendEmail(to, carbonc.getText().toString(), naslov.getText().toString(), poruka.getText().toString());

    }

    private void sendEmail(String[] emailAddresses, String carbonCopies,
                           String subject, String message)
    {

        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setData(Uri.parse("mailto:"));
        String[] to = emailAddresses;
        String cc = carbonCopies;
        emailIntent.putExtra(Intent.EXTRA_EMAIL, to);
        emailIntent.putExtra(Intent.EXTRA_CC, cc);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
        emailIntent.putExtra(Intent.EXTRA_TEXT, message);
        emailIntent.setType("message/rfc822");
        startActivity(Intent.createChooser(emailIntent, "Email"));
    }
}
